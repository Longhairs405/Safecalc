import math
from typing import Optional, Union, Dict, Tuple
from dataclasses import dataclass

PHI = (1 + 5**0.5) / 2
PHI_INV = 1 / PHI
D = math.log(3) / math.log(2)
EPS = 2.220446049250313e-16
FLOAT_MAX = 1.7976931348623157e308
FLOAT_DENORM_MIN = 5e-324


class Rational:
    __slots__ = ('num', 'den')
    
    def __init__(self, n, d=1):
        if isinstance(n, Rational):
            self.num, self.den = n.num, n.den
            return
        if d == 0:
            raise ZeroDivisionError()
        if d < 0:
            n, d = -n, -d
        g = math.gcd(abs(n), d)
        self.num = n // g
        self.den = d // g
    
    def __add__(self, o):
        if isinstance(o, (int, float)): o = Rational(int(o))
        return Rational(self.num * o.den + o.num * self.den, self.den * o.den)
    
    def __sub__(self, o):
        if isinstance(o, (int, float)): o = Rational(int(o))
        return Rational(self.num * o.den - o.num * self.den, self.den * o.den)
    
    def __mul__(self, o):
        if isinstance(o, (int, float)): o = Rational(int(o))
        return Rational(self.num * o.num, self.den * o.den)
    
    def __truediv__(self, o):
        if isinstance(o, (int, float)): o = Rational(int(o))
        if o.num == 0: raise ZeroDivisionError()
        return Rational(self.num * o.den, self.den * o.num)
    
    def __neg__(self): return Rational(-self.num, self.den)
    def __eq__(self, o): return isinstance(o, Rational) and self.num == o.num and self.den == o.den
    def __float__(self): return self.num / self.den
    def __repr__(self): return str(self.num) if self.den == 1 else f"{self.num}/{self.den}"
    def is_integer(self): return self.den == 1


class PhiNumber:
    __slots__ = ('a', 'b', 'strand', 'scale')
    
    def __init__(self, a, b=0, strand=1, scale=1):
        self.a = a if isinstance(a, Rational) else Rational(a)
        self.b = b if isinstance(b, Rational) else Rational(b)
        self.strand = strand
        self.scale = scale
    
    @classmethod
    def phi(cls): return cls(0, 1)
    @classmethod
    def one(cls): return cls(1, 0)
    @classmethod
    def zero(cls): return cls(0, 0)
    
    def __add__(self, o):
        if not isinstance(o, PhiNumber): o = PhiNumber(o)
        return PhiNumber(self.a + o.a, self.b + o.b, self.strand, max(self.scale, o.scale))
    
    def __mul__(self, o):
        if not isinstance(o, PhiNumber): o = PhiNumber(o)
        a1, b1, a2, b2 = self.a, self.b, o.a, o.b
        return PhiNumber(
            a1 * a2 + b1 * b2,
            a1 * b2 + b1 * a2 + b1 * b2,
            self.strand * o.strand,
            max(self.scale, o.scale)
        )
    
    def __truediv__(self, o):
        if not isinstance(o, PhiNumber): o = PhiNumber(o)
        c, d = o.a, o.b
        norm = c * c + c * d - d * d
        if norm == Rational(0): raise ZeroDivisionError()
        conj = PhiNumber(c + d, -d, o.strand, o.scale)
        num = self * conj
        return PhiNumber(num.a / norm, num.b / norm, self.strand, max(self.scale, o.scale))
    
    def __neg__(self): return PhiNumber(-self.a, -self.b, self.strand, self.scale)
    def __eq__(self, o): return isinstance(o, PhiNumber) and self.a == o.a and self.b == o.b and self.strand == o.strand
    def __repr__(self): return f"({self.a} + {self.b}φ)"
    def to_float(self): return (float(self.a) + float(self.b) * PHI) * self.strand
    def is_integer(self): return self.b == Rational(0) and self.a.is_integer()


class HelixInteger:
    __slots__ = ('level', 'strand', 'scale')
    
    def __init__(self, level: int, strand: int = 1, scale: int = 1):
        self.level = level
        self.strand = strand
        self.scale = scale
    
    def __mul__(self, o):
        return HelixInteger(
            self.level * o.level,
            self.strand * o.strand,
            max(self.scale, o.scale)
        )
    
    def to_phinumber(self):
        return PhiNumber(Rational(self.level), Rational(0), self.strand, self.scale)
    
    def __repr__(self):
        sign = '+' if self.strand == 1 else '-'
        return f"HelixInteger({sign}{self.level}, scale={self.scale})"


class UmbrilFloat:
    __slots__ = ('_1', '_2', '_3', '_0')
    
    def __init__(self, value):
        self._1 = float(value)
        self._2 = EPS * abs(self._1)
        self._3 = None
        self._0 = None
    
    def _close(self):
        if self._3 is None:
            self._3 = self._1 + self._2
            self._0 = self._3 - self._1
    
    @property
    def v(self): return self._1
    @property
    def shadow(self): return self._2
    @property
    def obs(self): self._close(); return self._3
    @property
    def bound(self): self._close(); return self._0
    @property
    def grid_scale(self):
        m = abs(self._1); return 0 if m == 0 else round(math.log(max(m, 1e-300), 3))
    @property
    def phi_distance(self): return abs(abs(self._1) - PHI)
    
    def __add__(self, o):
        if not isinstance(o, UmbrilFloat): o = UmbrilFloat(o)
        r = UmbrilFloat.__new__(UmbrilFloat)
        r._1 = self._1 + o._1; r._2 = self._2 + o._2
        r._3 = r._0 = None; return r
    
    def __radd__(self, o): return self + UmbrilFloat(o)
    
    def __sub__(self, o):
        if not isinstance(o, UmbrilFloat): o = UmbrilFloat(o)
        return self + UmbrilFloat(-o._1)
    
    def __mul__(self, o):
        if not isinstance(o, UmbrilFloat): o = UmbrilFloat(o)
        r = UmbrilFloat.__new__(UmbrilFloat)
        r._1 = self._1 * o._1
        r._2 = abs(self._1) * o._2 + abs(o._1) * self._2 + self._2 * o._2
        r._3 = r._0 = None; return r
    
    def __rmul__(self, o): return self * UmbrilFloat(o)
    
    def __truediv__(self, o):
        if not isinstance(o, UmbrilFloat): o = UmbrilFloat(o)
        r = UmbrilFloat.__new__(UmbrilFloat)
        r._1 = self._1 / o._1
        r._2 = (abs(self._1) * o._2 / max(o._1**2, 1e-300) + self._2 / max(abs(o._1), 1e-300))
        r._3 = r._0 = None; return r
    
    def __neg__(self):
        r = UmbrilFloat.__new__(UmbrilFloat)
        r._1 = -self._1; r._2 = self._2; r._3 = r._0 = None; return r
    
    def equals(self, o, tol=10):
        if not isinstance(o, UmbrilFloat): o = UmbrilFloat(o)
        return abs(self._1 - o._1) <= tol * max(abs(self._1), abs(o._1), 1.0) * EPS
    
    def __eq__(self, o):
        if isinstance(o, (UmbrilFloat, float, int)): return self.equals(o)
        return NotImplemented
    
    def __float__(self): return self._1
    def __repr__(self): return f"UF({self._1:.6g})"
    def __str__(self): return str(self._1)


class StackNumber:
    
    def __init__(self, value, scale: int = 1):
        self.value = value if isinstance(value, PhiNumber) else PhiNumber(value)
        self.scale = scale
    
    def triad_closure(self): return 3 * self.scale
    def container(self): return 3 * (self.scale - 1) if self.scale > 1 else 1
    
    def project_up(self):
        if not self.value.is_integer():
            raise ValueError("Can only project integer values up")
        level = int(float(self.value.a))
        if level % (3 * self.scale) != 0:
            raise ValueError(f"Level {level} not divisible by {3 * self.scale}")
        return StackNumber(PhiNumber(level // (3 * self.scale)), self.scale + 1)
    
    def project_down(self):
        if self.scale <= 1:
            raise ValueError("Cannot project down from scale 1")
        if not self.value.is_integer():
            raise ValueError("Can only project integer values down")
        level = int(float(self.value.a))
        return StackNumber(PhiNumber(level * 3 * (self.scale - 1)), self.scale - 1)
    
    def __repr__(self):
        return f"StackNumber({self.value}, scale={self.scale})"


class GuardedFloat:
    
    @staticmethod
    def safe(value, fallback=0.0):
        if math.isnan(value) or math.isinf(value): return fallback
        if abs(value) < FLOAT_DENORM_MIN: return 0.0
        if abs(value) > FLOAT_MAX / 10:
            return math.copysign(FLOAT_MAX / 10, value)
        return value
    
    @staticmethod
    def phi_normalize(value):
        val = GuardedFloat.safe(value, PHI_INV)
        if val == 0: return PHI_INV
        abs_val = abs(val)
        if abs_val > PHI**10:
            scale = PHI ** (-round(math.log(abs_val, PHI)) + 1)
            return val * scale
        elif abs_val < PHI_INV**5:
            scale = PHI ** (round(-math.log(abs_val, PHI)) + 1)
            return val * scale
        return val
