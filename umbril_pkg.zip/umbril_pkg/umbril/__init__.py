"""Umbril — Triune Fractal Theorem Library"""

__version__ = "1.0.0"

from umbril.core import (
    UmbrilFloat, PhiNumber, Rational, HelixInteger,
    StackNumber, GuardedFloat, PHI, PHI_INV, D, EPS,
)
from umbril.stability import (
    SpectralMonitor, StabilityStatus, FailureMode,
    monitor_stability, ZetaDifferential,
)
from umbril.projection import (
    UmbrilProjection, ShadowReconstruction,
)
from umbril.analysis import (
    RiemannAnalyzer, TriuneSolver, TriuneRuntime,
    MillenniumSuite, Verdict, CoherenceLevel,
)
