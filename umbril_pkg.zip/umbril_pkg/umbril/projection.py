import math

PHI = (1 + 5**0.5) / 2
PHI_INV = 1 / PHI


class UmbrilProjection:
    """
    Projection from higher-dimensional helix to lower-dimensional
    observational plain. Models shadow geometry.
    """
    
    def __init__(self, source_dim: int, target_dim: int):
        if source_dim <= target_dim:
            raise ValueError("source_dim must exceed target_dim")
        self.source_dim = source_dim
        self.target_dim = target_dim
        self.codim = source_dim - target_dim
        self.singular_set = []
    
    def shadow_dimension(self, epsilon: float = 0.0) -> float:
        """Hausdorff dimension of the shadow: dim_H = m - (n-m)/φ² + ε"""
        return self.target_dim - (self.codim / (PHI * PHI)) + epsilon
    
    def optimal_loss(self) -> float:
        """Minimal information loss for this codimension: ℒ_min = φ^{-codim}"""
        return PHI_INV ** self.codim
    
    def information_loss(self, singular_volume: float, total_volume: float) -> float:
        """Information lost: ℒ = (Vol(S)/Vol(M)) × φ^{codim}"""
        if total_volume == 0:
            return float('inf')
        return (singular_volume / total_volume) * (PHI ** self.codim)
    
    def add_singular_point(self, point):
        """Add a point to the singular set."""
        self.singular_set.append(point)
    
    def is_singular(self, point) -> bool:
        """Check if a point is in the singular set."""
        return point in self.singular_set


class ShadowReconstruction:
    """
    Attempt to reconstruct the original helix from its shadow.
    Possible when dim_H(shadow) > dim(Y) - 1/φ².
    """
    
    def __init__(self, projection: UmbrilProjection):
        self.proj = projection
    
    def is_reconstructible(self, shadow_dim: float) -> bool:
        """Check if reconstruction is theoretically possible."""
        threshold = self.proj.target_dim - (1 / (PHI * PHI))
        return shadow_dim > threshold
    
    def error_bound(self) -> float:
        """Minimal reconstruction error: φ^{-codim}"""
        return PHI_INV ** self.proj.codim
    
    def attempt(self, shadow, shadow_dim: float = None, singular_data=None):
        """
        Attempt to lift shadow back to original helix.
        Returns (reconstructed, confidence) where confidence in [0,1].
        """
        if shadow_dim is None:
            shadow_dim = self.proj.shadow_dimension()
        
        if not self.is_reconstructible(shadow_dim):
            return None, 0.0
        
        threshold = self.proj.target_dim - (1 / (PHI * PHI))
        confidence = min(1.0, (shadow_dim - threshold) / (1 / (PHI * PHI)))
        
        if hasattr(shadow, '__mul__'):
            reconstructed = shadow * (PHI ** self.proj.codim)
        else:
            reconstructed = shadow * (PHI ** self.proj.codim)
        
        return reconstructed, confidence
