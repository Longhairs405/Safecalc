import math
import cmath
import contextlib
import functools
from enum import Enum, auto
from typing import List, Dict, Optional, Generator
from dataclasses import dataclass, field

PHI = (1 + 5**0.5) / 2
PHI_INV = 1 / PHI
EPS = 2.220446049250313e-16
MANTISSA_BITS = 53


class StabilityStatus(Enum):
    STABLE = auto()
    CONVERGING = auto()
    MARGINAL = auto()
    UNSTABLE = auto()
    FROZEN = auto()
    UNKNOWN = auto()


class FailureMode(Enum):
    NONE = auto()
    TYPE_I_FROZEN = auto()
    TYPE_II_ENTROPY_FLOOD = auto()
    TYPE_III_OSCILLATORY = auto()
    TYPE_IV_ENTROPY_LEAKAGE = auto()


@dataclass
class SpectralPage:
    page_number: int
    entries: Dict = field(default_factory=dict)
    
    def set(self, s, t, value):
        self.entries[(s, t)] = value
    
    def get(self, s, t, default=0j):
        return self.entries.get((s, t), default)


class ZetaDifferential:
    
    @staticmethod
    def weight(r: int, precision_loss: float) -> float:
        if r < 1:
            return 0.0
        base = precision_loss ** (r * PHI_INV)
        zeta_analog = sum((2.0**k)**-r for k in range(1, MANTISSA_BITS + 1))
        return base * zeta_analog
    
    @staticmethod
    def apply(page: SpectralPage, r: int, precision_loss: float) -> SpectralPage:
        w = ZetaDifferential.weight(r, precision_loss)
        new_page = SpectralPage(page_number=r + 1)
        
        for k, v in page.entries.items():
            new_page.set(*k, v)
        
        for (s, t), val in page.entries.items():
            if abs(val) < 1e-300:
                continue
            ts, tt = s + r, t - r + 1
            diff = val * w * cmath.exp(2j * math.pi * PHI_INV * r)
            new_page.set(ts, tt, new_page.get(ts, tt) - diff)
        
        return new_page


class SpectralMonitor:
    
    def __init__(self, name="monitor"):
        self.name = name
        self._ops = []
        self._losses = []
        self._cum_loss = 0.0
        self._pages = [SpectralPage(page_number=1)]
        self._init = False
    
    def track_value(self, value: float, label: str = ""):
        self._ops = []
        self._losses = []
        self._cum_loss = 0.0
        self._pages = [SpectralPage(page_number=1)]
        self._init = True
        
        page = self._pages[0]
        if value == 0.0:
            page.set(0, 0, 0j)
        else:
            mantissa, exponent = math.frexp(value)
            for bp in range(MANTISSA_BITS):
                bit_val = (int(mantissa * 2**MANTISSA_BITS) >> (MANTISSA_BITS - 1 - bp)) & 1
                if bit_val:
                    page.set(bp, exponent + bp, complex(2.0**(-bp-1), 0.0))
            page.set(-1, exponent, complex(1.0, 0.0))
        
        self._ops.append(f"init({value})" + (f" # {label}" if label else ""))
        self._losses.append(0.0)
    
    def track(self, op: str, result: float, *operands: float):
        if not self._init:
            self.track_value(operands[0] if operands else result)
        
        ideal = self._ideal(op, list(operands))
        loss = abs(ideal - result) / max(abs(ideal), 1e-300) if abs(ideal) > 1e-300 else abs(result)
        
        self._cum_loss += loss
        self._losses.append(loss)
        
        op_str = f"{op}(" + ", ".join(str(o)[:10] for o in operands) + f") = {result:.6g}"
        if loss > 0.01:
            op_str += f" LOSS={loss:.2e}"
        self._ops.append(op_str)
        
        r = len(self._pages)
        self._pages.append(ZetaDifferential.apply(self._pages[-1], r, loss))
    
    def _ideal(self, op: str, operands: list) -> float:
        if op == 'add': return sum(operands)
        if op == 'sub': return operands[0] - sum(operands[1:])
        if op == 'mul': return functools.reduce(lambda a, b: a * b, operands, 1.0)
        if op == 'div': return functools.reduce(lambda a, b: a / b, operands[1:], operands[0])
        if op == 'sqrt': return math.sqrt(operands[0])
        if op == 'exp': return math.exp(operands[0])
        if op == 'log': return math.log(operands[0])
        if op == 'sin': return math.sin(operands[0])
        if op == 'cos': return math.cos(operands[0])
        return operands[0]
    
    def diagnose(self) -> Dict:
        loss_ratio = self._cum_loss / PHI_INV
        
        if loss_ratio < 0.01:
            status = StabilityStatus.STABLE
        elif loss_ratio < 0.1:
            status = StabilityStatus.CONVERGING
        elif loss_ratio < 1.0:
            status = StabilityStatus.MARGINAL
        elif loss_ratio < 10:
            status = StabilityStatus.UNSTABLE
        else:
            status = StabilityStatus.FROZEN
        
        if status == StabilityStatus.UNSTABLE:
            failure = FailureMode.TYPE_II_ENTROPY_FLOOD if self._cum_loss > 10 else FailureMode.TYPE_III_OSCILLATORY
        elif status == StabilityStatus.FROZEN:
            failure = FailureMode.TYPE_I_FROZEN
        else:
            failure = FailureMode.NONE
        
        return {
            'status': status,
            'failure': failure,
            'cum_loss': self._cum_loss,
            'loss_ratio': loss_ratio,
            'ops': len(self._ops),
        }
    
    def report(self):
        d = self.diagnose()
        
        emoji = {
            StabilityStatus.STABLE: 'STABLE',
            StabilityStatus.CONVERGING: 'CONVERGING',
            StabilityStatus.MARGINAL: 'MARGINAL',
            StabilityStatus.UNSTABLE: 'UNSTABLE',
            StabilityStatus.FROZEN: 'FROZEN',
            StabilityStatus.UNKNOWN: 'UNKNOWN',
        }
        
        femoji = {
            FailureMode.NONE: '',
            FailureMode.TYPE_I_FROZEN: 'FROZEN',
            FailureMode.TYPE_II_ENTROPY_FLOOD: 'ENTROPY_FLOOD',
            FailureMode.TYPE_III_OSCILLATORY: 'OSCILLATORY',
            FailureMode.TYPE_IV_ENTROPY_LEAKAGE: 'LEAKAGE',
        }
        
        print(f"\n{'='*55}")
        print(f"  SPECTRAL REPORT: {self.name}")
        print(f"{'='*55}")
        print(f"  Status: {emoji[d['status']]}")
        if d['failure'] != FailureMode.NONE:
            print(f"  Failure: {femoji[d['failure']]}")
        print(f"  Cumulative loss: {d['cum_loss']:.4f}")
        print(f"  Loss ratio: {d['loss_ratio']:.4f} (φ⁻¹ = {PHI_INV:.4f})")
        print(f"  Operations: {d['ops']}")
        print(f"{'='*55}")


@contextlib.contextmanager
def monitor_stability(name: str = "Computation") -> Generator[SpectralMonitor, None, None]:
    monitor = SpectralMonitor(name)
    try:
        yield monitor
    finally:
        pass
