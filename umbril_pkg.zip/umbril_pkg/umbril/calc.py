#!/usr/bin/env python3
"""
Safe Calculator — Triune Fractal Theorem
=========================================
Fixes floating-point math + professional / advanced tools.
Type math. Get correct answers.

BASIC:        + - * / × ÷
FUNCTIONS:    sqrt sin cos tan log exp
CONSTANTS:    pi e phi

PROFESSIONAL PRECISION:
  /precision expr             Show error shadow

TRAJECTORY & PHYSICS:
  /proj v angle [h0] [g]      Projectile range, max height, time
  /orbit m1 m2 r              Orbital period & velocity
  /kepler a e theta           Position from orbital elements

STATISTICS:
  /mean numbers...            Arithmetic mean (stable)
  /var numbers...             Variance (Welford)
  /reg x1 y1 x2 y2 ...        Linear regression

NUMERICAL METHODS:
  /root expr a b [n]          Bisection root finder
  /integrate expr a b [n]     Simpson integration
  /solve a b c d e f          Solve 2x2 linear system

MATRIX OPS:
  /det a b c d                Determinant of 2x2
  /eig a b c d                Eigenvalues of 2x2

SIGNAL:
  /fft values...              DFT magnitudes
  /conv a... -- b...          Convolution

FINANCE / CONSTRUCTION / DESIGN:
  /compound P r yrs [n]       Compound interest
  /mortgage P r yrs           Monthly payment
  /npv r cashflows...         Net present value
  /tax amount [rate]          Add tax
  /tip amount [rate]          Calculate tip
  /area shape dims...         Area
  /volume shape dims...       Volume
  /slope rise run             Slope
  /materials area cov         Material units
  /golden value               Phi proportions
  /scale factor value         Precise scaling
  /aspect w h                 Aspect ratio

MEMORY: /mem m+|m-|mr|mc [val]
HISTORY: /history
HELP: /help | QUIT: /quit
"""

import math, re, sys, os

sys.path.insert(0, os.path.expanduser('~/umbril_pkg'))
from umbril.core import UmbrilFloat, PHI, PHI_INV, EPS

# ---------- wrappers ----------
def uf(v):
    return v if isinstance(v, UmbrilFloat) else UmbrilFloat(v)

def _uf2(x):
    return uf(math.sqrt(float(x)))
def _uf3(x):
    return uf(math.sin(float(x)))
def _uf4(x):
    return uf(math.cos(float(x)))
def _uf5(x):
    return uf(math.tan(float(x)))
def _uf6(x):
    return uf(math.log(float(x)))
def _uf7(x):
    return uf(math.exp(float(x)))

def compute(expr):
    expr = expr.replace('x', '*').replace('/', '/')
    expr = re.sub(r'(\d+\.?\d*)', r'UmbrilFloat(\1)', expr)
    env = {
        'UmbrilFloat': UmbrilFloat,
        'float': float, 'int': int, 'abs': abs, 'round': round,
        'min': min, 'max': max, 'sum': sum,
        'pi': uf(math.pi), 'e': uf(math.e), 'phi': uf(PHI),
        'sqrt': _uf2, 'sin': _uf3, 'cos': _uf4,
        'tan': _uf5, 'log': _uf6, 'exp': _uf7,
        'pow': pow, '__builtins__': None,
    }
    try:
        r = eval(expr, env)
        if isinstance(r, UmbrilFloat):
            return float(r), r.shadow
        return float(r), None
    except Exception as e:
        return str(e), None

def fmt(v):
    if isinstance(v, str): return v
    if abs(v) < 1e-12: return "0"
    if abs(v) >= 1e12 or (abs(v) < 1e-6 and v!=0): return f"{v:.10g}"
    s = f"{v:.15g}"
    if '.' in s: s = s.rstrip('0').rstrip('.')
    return s

def fm(v): return f"${v:,.2f}"

# ---------- memory / history ----------
memory = uf(0); history = []

def cmd_mem(parts):
    global memory
    if len(parts)<2: return "Usage: /mem m+|m-|mr|mc [val]"
    act = parts[1].lower()
    if act=='m+' and len(parts)>=3:
        memory=memory+uf(float(parts[2]))
        return f"M+ {fmt(float(parts[2]))} -> memory={fmt(float(memory))}"
    if act=='m-' and len(parts)>=3:
        memory=memory-uf(float(parts[2]))
        return f"M- {fmt(float(parts[2]))} -> memory={fmt(float(memory))}"
    if act=='mr': return f"Memory={fmt(float(memory))}"
    if act=='mc': memory=uf(0); return "Memory cleared"
    return "Usage: /mem m+|m-|mr|mc [val]"

# ---------- finance ----------
def cmd_compound(p):
    if len(p)<4: return "Usage: /compound P r yrs [n/yr]"
    P=uf(float(p[1])); r=uf(float(p[2])/100); yrs=float(p[3])
    n=float(p[4]) if len(p)>=5 else 1.0
    A=P*uf((1+float(r/n))**(n*yrs))
    return f"Principal: {fm(float(P))}\n  Rate: {fmt(float(r)*100)}% over {fmt(yrs)}y\n  Total: {fm(float(A))}  Interest: {fm(float(A-P))}"

def cmd_mortgage(p):
    if len(p)<4: return "Usage: /mortgage P r yrs"
    P=uf(float(p[1])); r=uf(float(p[2])/100/12); n=int(float(p[3])*12)
    if float(r)==0: M=P/uf(n)
    else: M=P*(r*uf((1+float(r))**n))/(uf((1+float(r))**n)-uf(1))
    T=M*uf(n)
    return f"Loan: {fm(float(P))} at {fmt(float(r)*1200)}% {p[3]}y\n  Monthly: {fm(float(M))}\n  Total: {fm(float(T))} (Interest: {fm(float(T-P))})"

def cmd_npv(p):
    if len(p)<3: return "Usage: /npv rate cf1 cf2 ..."
    r=uf(float(p[1])/100); t=uf(0)
    for i,cf in enumerate(p[2:]): t=t+uf(float(cf))/uf((1+float(r))**i)
    return f"NPV at {fmt(float(r)*100)}%: {fm(float(t))}"

def cmd_tax(p):
    if len(p)>=2:
        a=float(p[1]); r=float(p[2]) if len(p)>=3 else 8.5
        return f"Amount: {fm(a)} Tax({r}%): {fm(a*r/100)} Total: {fm(a*(1+r/100))}"
    return "Usage: /tax amount [rate%]"

def cmd_tip(p):
    if len(p)>=2:
        a=float(p[1]); r=float(p[2]) if len(p)>=3 else 18
        return f"Bill: {fm(a)} Tip({r}%): {fm(a*r/100)} Total: {fm(a*(1+r/100))}"
    return "Usage: /tip amount [rate%]"

# ---------- construction ----------
def cmd_area(p):
    if len(p)<3: return "Usage: /area rect w h | circle r | triangle b h"
    try:
        s=p[1].lower()
        if s=='rect' and len(p)>=4: return f"Rectangle {fmt(float(p[2]))}x{fmt(float(p[3]))}: Area={fmt(float(p[2])*float(p[3]))}"
        if s=='circle' and len(p)>=3: return f"Circle r={fmt(float(p[2]))}: Area={fmt(math.pi*float(p[2])**2)}"
        if s=='triangle' and len(p)>=4: return f"Triangle b={fmt(float(p[2]))} h={fmt(float(p[3]))}: Area={fmt(0.5*float(p[2])*float(p[3]))}"
    except: pass
    return "Usage: /area rect w h | circle r | triangle b h"

def cmd_volume(p):
    if len(p)<3: return "Usage: /volume box w h d | cylinder r h | sphere r"
    try:
        s=p[1].lower()
        if s=='box' and len(p)>=5: return f"Box {fmt(float(p[2]))}x{fmt(float(p[3]))}x{fmt(float(p[4]))}: Vol={fmt(float(p[2])*float(p[3])*float(p[4]))}"
        if s=='cylinder' and len(p)>=4: return f"Cyl r={fmt(float(p[2]))} h={fmt(float(p[3]))}: Vol={fmt(math.pi*float(p[2])**2*float(p[3]))}"
        if s=='sphere' and len(p)>=3: return f"Sphere r={fmt(float(p[2]))}: Vol={fmt(4/3*math.pi*float(p[2])**3)}"
    except: pass
    return "Usage: /volume box w h d | cylinder r h | sphere r"

def cmd_slope(p):
    if len(p)<3: return "Usage: /slope rise run"
    r,n=float(p[1]),float(p[2]); ra=r/n if n else float('inf')
    return f"Rise={fmt(r)} Run={fmt(n)}: Slope={fmt(ra)} ({fmt(ra*100)}%, {fmt(math.degrees(math.atan(ra)))}°)"

def cmd_materials(p):
    if len(p)<3: return "Usage: /materials area cov"
    a,c=float(p[1]),float(p[2]); return f"Area:{fmt(a)} Cov/unit:{fmt(c)} Units:{math.ceil(a/c)}"

# ---------- design ----------
def cmd_golden(p):
    if len(p)<2: return "Usage: /golden value"
    v=float(p[1]); return f"{fmt(v)} x φ = {fmt(v*PHI)}    {fmt(v)} / φ = {fmt(v*PHI_INV)}"

def cmd_scale(p):
    if len(p)<3: return "Usage: /scale factor value"
    return f"{fmt(float(p[2]))} x {fmt(float(p[1]))} = {fmt(float(p[1])*float(p[2]))}"

def cmd_aspect(p):
    if len(p)<3: return "Usage: /aspect w h"
    w,h=float(p[1]),float(p[2]); ra=w/h if h else 0
    common={1.33:"4:3",1.5:"3:2",1.6:"16:10",1.777:"16:9",1.0:"1:1",1.414:"A-series",1.618:"Golden"}
    cl=min(common,key=lambda k:abs(k-ra))
    return f"Aspect {fmt(w)}:{fmt(h)} = {fmt(ra)} (nearest: {common[cl]})"

# ---------- precision ----------
def cmd_precision(p):
    if len(p)<2: return "Usage: /precision expr"
    val,shadow=compute(' '.join(p[1:]))
    if isinstance(val,str): return f"Error: {val}"
    if shadow is None: return f"{fmt(val)} [no shadow]"
    ratio=shadow/max(abs(val),1e-300)
    if abs(val)<1e-12 and shadow<1e-12: trust="EXACT"
    elif ratio<1e-10: trust="EXACT"
    elif ratio<1e-6: trust="GOOD"
    elif ratio<1e-3: trust="WARN"
    else: trust="BAD"
    return f"{fmt(val)} shadow=±{shadow:.2e} trust={trust}"

# ---------- floating-point tools ----------
def cmd_kahan(p):
    if len(p)<2: return "Usage: /sum nums..."
    nums=[float(x) for x in p[1:]]; t,c=uf(0),uf(0)
    for n in nums: y=uf(n)-c; tt=t+y; c=(tt-t)-y; t=tt
    naive=sum(nums)
    return f"Naive:{fmt(naive)} Kahan:{fmt(float(t))} Diff:{fmt(abs(naive-float(t)))}"

def cmd_horner(p):
    if len(p)<3: return "Usage: /poly x a0 a1..."
    x=uf(float(p[1])); cs=[uf(float(x)) for x in p[2:]]; r=uf(0)
    for c in reversed(cs): r=r*x+c
    return f"P({fmt(float(x))}) = {fmt(float(r))}"

def cmd_quad(p):
    if len(p)<4: return "Usage: /quad a b c"
    a,b,c=uf(float(p[1])),uf(float(p[2])),uf(float(p[3]))
    disc=b*b-uf(4)*a*c
    if float(disc)<0: return f"No real roots (disc={fmt(float(disc))})"
    sd=uf(math.sqrt(float(disc)))
    if float(b)>=0:
        x1=(-b-sd)/(uf(2)*a); x2=(uf(2)*c)/(-b-sd)
    else:
        x1=(uf(2)*c)/(-b+sd); x2=(-b+sd)/(uf(2)*a)
    return f"x1={fmt(float(x1))} x2={fmt(float(x2))} disc={fmt(float(disc))}"

def cmd_dot(p):
    if '--' not in p: return "Usage: /dot a1 a2 ... -- b1 b2 ..."
    sep=p.index('--'); a=[uf(float(x)) for x in p[1:sep]]; b=[uf(float(x)) for x in p[sep+1:]]
    if len(a)!=len(b): return "Vectors must be same length"
    t,c=uf(0),uf(0)
    for ai,bi in zip(a,b): y=ai*bi-c; tt=t+y; c=(tt-t)-y; t=tt
    naive=sum(float(ai)*float(bi) for ai,bi in zip(a,b))
    return f"Dot: {fmt(float(t))} (naive: {fmt(naive)})"

# ---------- trajectory ----------
def cmd_proj(p):
    if len(p)<3: return "Usage: /proj v angle [h0] [g]"
    v0=float(p[1]); th=math.radians(float(p[2]))
    h0=float(p[3]) if len(p)>=4 else 0.0; g=float(p[4]) if len(p)>=5 else 9.80665
    vx=v0*math.cos(th); vy=v0*math.sin(th)
    tpk=vy/g; hmax=h0+vy*tpk-0.5*g*tpk*tpk
    ttot=(vy+math.sqrt(vy*vy+2*g*h0))/g; rng=vx*ttot
    return f"Range: {fmt(rng)} m\n  Max height: {fmt(hmax)} m\n  Time: {fmt(ttot)} s\n  g={fmt(g)} angle={fmt(float(p[2]))}°"

def cmd_orbit(p):
    if len(p)<4: return "Usage: /orbit m1 m2 r"
    G=6.67430e-11; m1,m2,r=float(p[1]),float(p[2]),float(p[3])
    mu=G*(m1+m2); v=math.sqrt(mu/r); T=2*math.pi*math.sqrt(r**3/mu)
    return f"Orbital v: {fmt(v)} m/s\n  Period: {fmt(T)} s ({fmt(T/3600)} h, {fmt(T/86400)} days)"

def cmd_kepler(p):
    if len(p)<4: return "Usage: /kepler a e theta"
    a,e,th=float(p[1]),float(p[2]),math.radians(float(p[3]))
    r=a*(1-e*e)/(1+e*math.cos(th))
    return f"Distance: {fmt(r)} AU (a={fmt(a)}, e={fmt(e)}, θ={fmt(math.degrees(th))}°)"

# ---------- statistics ----------
def cmd_mean(p):
    if len(p)<2: return "Usage: /mean nums..."
    nums=[float(x) for x in p[1:]]; t,c=uf(0),uf(0)
    for n in nums: y=uf(n)-c; tt=t+y; c=(tt-t)-y; t=tt
    return f"Mean: {fmt(float(t)/len(nums))} ({len(nums)} values)"

def cmd_var(p):
    if len(p)<2: return "Usage: /var nums..."
    nums=[float(x) for x in p[1:]]; mean=uf(0); M2=uf(0)
    for i,n in enumerate(nums,1):
        d=uf(n)-mean; mean=mean+d/uf(i); d2=uf(n)-mean; M2=M2+d*d2
    v=M2/uf(len(nums)); std=uf(math.sqrt(float(v)))
    return f"Var: {fmt(float(v))}  Std: {fmt(float(std))}  Mean: {fmt(float(mean))}"

def cmd_reg(p):
    if len(p)<5 or (len(p)-1)%2!=0: return "Usage: /reg x1 y1 x2 y2 ..."
    n=(len(p)-1)//2; xs=[float(p[i]) for i in range(1,len(p),2)]; ys=[float(p[i]) for i in range(2,len(p),2)]
    mx=sum(xs)/n; my=sum(ys)/n; num=den=0.0
    for x,y in zip(xs,ys): dx=x-mx; num+=dx*(y-my); den+=dx*dx
    sl=num/den if den else 0; ic=my-sl*mx
    nr=dr1=dr2=0.0
    for x,y in zip(xs,ys): dx=x-mx; dy=y-my; nr+=dx*dy; dr1+=dx*dx; dr2+=dy*dy
    rr=nr/math.sqrt(dr1*dr2) if dr1*dr2 else 0
    return f"y = {fmt(ic)} + {fmt(sl)} x\n  r = {fmt(rr)} (r² = {fmt(rr*rr)})"

# ---------- numerical methods ----------
def cmd_root(p):
    if len(p)<4: return "Usage: /root expr a b [n=50]"
    expr=p[1]; a=float(p[2]); b=float(p[3]); n=int(p[4]) if len(p)>=5 else 50
    fa,_=compute(expr.replace('x',str(a))); fb,_=compute(expr.replace('x',str(b)))
    if isinstance(fa,str) or isinstance(fb,str): return "Invalid function"
    if fa*fb>0: return f"f({fmt(a)})={fmt(fa)} f({fmt(b)})={fmt(fb)}: same sign"
    for i in range(n):
        m=(a+b)/2; fm,_=compute(expr.replace('x',str(m)))
        if isinstance(fm,str): return "Error in function"
        if fm==0 or (b-a)<1e-12: return f"Root: {fmt(m)} f={fmt(fm)} iters={i+1}"
        if fa*fm<0: b,fb=m,fm
        else: a,fa=m,fm
    return f"Root ≈ {fmt((a+b)/2)} after {n} iters"

def cmd_integrate(p):
    if len(p)<4: return "Usage: /integrate expr a b [n=100]"
    expr=p[1]; a=float(p[2]); b=float(p[3]); n=int(p[4]) if len(p)>=5 else 100
    if n%2: n+=1
    h=(b-a)/n
    fa,_=compute(expr.replace('x',str(a))); fb,_=compute(expr.replace('x',str(b)))
    if isinstance(fa,str) or isinstance(fb,str): return "Invalid function"
    t=fa+fb
    for i in range(1,n):
        xi=a+i*h; fi,_=compute(expr.replace('x',str(xi)))
        if isinstance(fi,str): return "Error in function"
        t+=fi*(4 if i%2 else 2)
    return f"Integral [{fmt(a)}, {fmt(b)}]: {fmt(float(t)*h/3)} (n={n})"

def cmd_solve(p):
    if len(p)<7: return "Usage: /solve a b c d e f"
    a,b,c,d,e,f=[float(x) for x in p[1:7]]
    det=a*d-b*c
    if abs(det)<1e-15: return "No unique solution (det=0)"
    x=(e*d-b*f)/det; y=(a*f-e*c)/det
    return f"x={fmt(x)} y={fmt(y)} det={fmt(det)}"

# ---------- matrix ----------
def cmd_det(p):
    if len(p)<5: return "Usage: /det a b c d"
    a,b,c,d=[float(x) for x in p[1:5]]
    return f"det = {fmt(a*d-b*c)}"

def cmd_eig(p):
    if len(p)<5: return "Usage: /eig a b c d"
    a,b,c,d=[float(x) for x in p[1:5]]
    tr=a+d; dt=a*d-b*c; disc=tr*tr-4*dt
    if disc<0:
        re=tr/2; im=math.sqrt(-disc)/2
        return f"λ1={fmt(re)}+{fmt(im)}i λ2={fmt(re)}-{fmt(im)}i"
    sd=math.sqrt(disc)
    return f"λ1={fmt((tr+sd)/2)} λ2={fmt((tr-sd)/2)}"

# ---------- signal ----------
def cmd_fft(p):
    if len(p)<2: return "Usage: /fft values..."
    vals=[float(x) for x in p[1:]]; N=len(vals); out="DFT:\n"
    for k in range(N//2+1):
        re=im=0.0
        for n,v in enumerate(vals):
            ang=-2*math.pi*k*n/N; re+=v*math.cos(ang); im+=v*math.sin(ang)
        mag=math.sqrt(re*re+im*im)
        if mag>1e-10: out+=f"  freq {k}: {fmt(mag)}\n"
    return out

def cmd_conv(p):
    if '--' not in p: return "Usage: /conv a1 a2 ... -- b1 b2 ..."
    sep=p.index('--'); a=[float(x) for x in p[1:sep]]; b=[float(x) for x in p[sep+1:]]
    n=len(a)+len(b)-1; r=[0.0]*n
    for i,av in enumerate(a):
        for j,bv in enumerate(b): r[i+j]+=av*bv
    return "Conv: "+", ".join(fmt(v) for v in r[:10])+(", ..." if n>10 else "")

# ---------- units ----------
LEN={'mm':0.001,'cm':0.01,'m':1.0,'km':1000.0,'in':0.0254,'ft':0.3048,'yd':0.9144,'mi':1609.344}
T_IN={'C':lambda c:c,'F':lambda f:(f-32)*5/9,'K':lambda k:k-273.15}
T_OUT={'C':lambda c:c,'F':lambda c:c*9/5+32,'K':lambda c:c+273.15}

def cmd_len(p):
    if len(p)>=4:
        v,fr,to=float(p[1]),p[2].lower(),p[3].lower()
        if fr in LEN and to in LEN: return f"{fmt(v)} {fr} = {fmt(v*LEN[fr]/LEN[to])} {to}"
    return "Usage: /len val from to"

def cmd_temp(p):
    if len(p)>=4:
        v,fr,to=float(p[1]),p[2].upper(),p[3].upper()
        if fr in T_IN and to in T_OUT: return f"{fmt(v)}°{fr} = {fmt(T_OUT[to](T_IN[fr](v)))}°{to}"
    return "Usage: /temp val from to"

# ---------- main ----------
print("="*60)
print("  SAFE CALCULATOR · Triune Fractal Theorem")
print("="*60)
print("  φ=1.618  Shadow tracking + φ-damping")
print("  Math · Finance · Construction · Design")
print("  Physics · Statistics · Numerical · Signal")
print("  /help for commands")
print()


def main():
    while True:
        try: raw=input("  ").strip()
        except (EOFError,KeyboardInterrupt): print(); break
        if not raw: continue
        if raw in('/quit','/q'): break
        if raw in('/help','/h'): print(__doc__); continue
        if raw=='/about':
            print("  Triune Fractal Theorem — UmbrilFloat shadow tracking")
            print("  Stable algorithms: Kahan sum, Welford var, Simpson,")
            print("  bisection, stable quadratic, Horner polynomial.")
            print("  0.1 + 0.2 = 0.3 (not 0.30000000000000004)")
            print(); continue
        if raw=='/history':
            print("  Recent:"); [print(f"    {i:35s} = {r}") for i,r in history[-10:]]; print(); continue

        parts=raw.split(); cmd=parts[0].lower(); out=None
        if cmd=='/mem': out=cmd_mem(parts)
        elif cmd=='/compound': out=cmd_compound(parts)
        elif cmd=='/mortgage': out=cmd_mortgage(parts)
        elif cmd=='/npv': out=cmd_npv(parts)
        elif cmd=='/tax': out=cmd_tax(parts)
        elif cmd=='/tip': out=cmd_tip(parts)
        elif cmd=='/area': out=cmd_area(parts)
        elif cmd=='/volume': out=cmd_volume(parts)
        elif cmd=='/slope': out=cmd_slope(parts)
        elif cmd=='/materials': out=cmd_materials(parts)
        elif cmd=='/golden': out=cmd_golden(parts)
        elif cmd=='/scale': out=cmd_scale(parts)
        elif cmd=='/aspect': out=cmd_aspect(parts)
        elif cmd=='/sum': out=cmd_kahan(parts)
        elif cmd=='/poly': out=cmd_horner(parts)
        elif cmd=='/quad': out=cmd_quad(parts)
        elif cmd=='/dot': out=cmd_dot(parts)
        elif cmd=='/precision': out=cmd_precision(parts)
        elif cmd=='/proj': out=cmd_proj(parts)
        elif cmd=='/orbit': out=cmd_orbit(parts)
        elif cmd=='/kepler': out=cmd_kepler(parts)
        elif cmd=='/mean': out=cmd_mean(parts)
        elif cmd=='/var': out=cmd_var(parts)
        elif cmd=='/reg': out=cmd_reg(parts)
        elif cmd=='/root': out=cmd_root(parts)
        elif cmd=='/integrate': out=cmd_integrate(parts)
        elif cmd=='/solve': out=cmd_solve(parts)
        elif cmd=='/det': out=cmd_det(parts)
        elif cmd=='/eig': out=cmd_eig(parts)
        elif cmd=='/fft': out=cmd_fft(parts)
        elif cmd=='/conv': out=cmd_conv(parts)
        elif cmd=='/len': out=cmd_len(parts)
        elif cmd=='/temp': out=cmd_temp(parts)
        else:
            val,_=compute(raw); out=fmt(val) if not isinstance(val,str) else f"Error: {val}"

        if out: print(f"  = {out}"); history.append((raw,out))

if __name__ == '__main__':
    main()
