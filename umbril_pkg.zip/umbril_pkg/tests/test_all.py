import sys
import os
import math
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from umbril.core import Rational, PhiNumber, UmbrilFloat, GuardedFloat, StackNumber, PHI, PHI_INV
from umbril.stability import SpectralMonitor, StabilityStatus, FailureMode, monitor_stability
from umbril.projection import UmbrilProjection, ShadowReconstruction
from umbril.analysis import (
    RiemannAnalyzer, TriuneSolver, TriuneRuntime,
    MillenniumSuite, Verdict, CoherenceLevel,
)


class TestRational(unittest.TestCase):
    
    def test_creation(self):
        r = Rational(3, 4)
        self.assertEqual(r.num, 3)
        self.assertEqual(r.den, 4)
        self.assertEqual(Rational(6, 8), r)
    
    def test_arithmetic(self):
        a = Rational(1, 2)
        b = Rational(1, 3)
        self.assertEqual(a + b, Rational(5, 6))
        self.assertEqual(a - b, Rational(1, 6))
        self.assertEqual(a * b, Rational(1, 6))
        self.assertEqual(a / b, Rational(3, 2))
    
    def test_negation(self):
        self.assertEqual(-Rational(1, 2), Rational(-1, 2))
    
    def test_float_conversion(self):
        self.assertAlmostEqual(float(Rational(1, 2)), 0.5)
    
    def test_integer_check(self):
        self.assertTrue(Rational(4, 2).is_integer())
        self.assertFalse(Rational(1, 2).is_integer())


class TestPhiNumber(unittest.TestCase):
    
    def test_phi_squared(self):
        phi = PhiNumber.phi()
        self.assertEqual(phi * phi, PhiNumber(1, 1))
    
    def test_phi_cubed(self):
        phi = PhiNumber.phi()
        self.assertEqual(phi * phi * phi, PhiNumber(1, 2))
    
    def test_phi_fourth(self):
        phi = PhiNumber.phi()
        phi4 = phi * phi * phi * phi
        self.assertEqual(phi4, PhiNumber(2, 3))
    
    def test_phi_fifth(self):
        phi = PhiNumber.phi()
        phi5 = phi * phi * phi * phi * phi
        self.assertEqual(phi5, PhiNumber(3, 5))
    
    def test_fibonacci_relation(self):
        phi = PhiNumber.phi()
        phi10 = phi
        for _ in range(9):
            phi10 = phi10 * phi
        self.assertEqual(phi10, PhiNumber(34, 55))
    
    def test_strand_parity(self):
        a = PhiNumber(2, 1, strand=1)
        b = PhiNumber(3, 0, strand=-1)
        c = a * b
        self.assertEqual(c.strand, -1)
    
    def test_division(self):
        phi = PhiNumber.phi()
        one = PhiNumber.one()
        self.assertEqual(phi / phi, one)
    
    def test_to_float(self):
        phi = PhiNumber.phi()
        self.assertAlmostEqual(phi.to_float(), PHI, places=5)


class TestUmbrilFloat(unittest.TestCase):
    
    def test_classic_problem(self):
        self.assertTrue(UmbrilFloat(0.1) + UmbrilFloat(0.2) == UmbrilFloat(0.3))
    
    def test_shadow_nonzero(self):
        u = UmbrilFloat(1.0)
        self.assertGreater(u.shadow, 0)
    
    def test_grid_scale(self):
        self.assertEqual(UmbrilFloat(3.0).grid_scale, 1)
        self.assertEqual(UmbrilFloat(9.0).grid_scale, 2)
    
    def test_addition(self):
        a = UmbrilFloat(2.0)
        b = UmbrilFloat(3.0)
        self.assertAlmostEqual(float(a + b), 5.0)
    
    def test_multiplication(self):
        a = UmbrilFloat(2.0)
        b = UmbrilFloat(3.0)
        self.assertAlmostEqual(float(a * b), 6.0)
    
    def test_phi_distance(self):
        u = UmbrilFloat(PHI)
        self.assertAlmostEqual(u.phi_distance, 0.0, places=5)


class TestGuardedFloat(unittest.TestCase):
    
    def test_nan_guard(self):
        self.assertEqual(GuardedFloat.safe(float('nan'), 0.0), 0.0)
    
    def test_inf_guard(self):
        self.assertEqual(GuardedFloat.safe(float('inf'), 1.0), 1.0)
    
    def test_normal_passthrough(self):
        self.assertEqual(GuardedFloat.safe(3.14, 0.0), 3.14)


class TestStackNumber(unittest.TestCase):
    
    def test_creation(self):
        sn = StackNumber(PhiNumber(3), scale=1)
        self.assertEqual(sn.scale, 1)
    
    def test_triad_closure(self):
        sn = StackNumber(PhiNumber(1), scale=2)
        self.assertEqual(sn.triad_closure(), 6)


class TestSpectralMonitor(unittest.TestCase):
    
    def test_creation(self):
        m = SpectralMonitor("test")
        self.assertEqual(m.name, "test")
    
    def test_stable_addition(self):
        m = SpectralMonitor("test")
        m.track_value(1.0)
        m.track('add', 3.0, 1.0, 2.0)
        d = m.diagnose()
        self.assertIn(d['status'], [StabilityStatus.STABLE, StabilityStatus.CONVERGING])
    
    def test_cancellation_detected(self):
        m = SpectralMonitor("cancel")
        a = 1.000000000000001
        b = 1.000000000000000
        m.track_value(a)
        m.track('sub', a - b, a, b)
        result = a - b
        for _ in range(3):
            result = result * 1000 - 0.001
            m.track('sub', result, result * 1000, 0.001)
        d = m.diagnose()
        self.assertEqual(d['failure'], FailureMode.TYPE_III_OSCILLATORY)


class TestUmbrilProjection(unittest.TestCase):
    
    def test_creation(self):
        proj = UmbrilProjection(3, 2)
        self.assertEqual(proj.codim, 1)
    
    def test_shadow_dimension(self):
        proj = UmbrilProjection(3, 2)
        dim = proj.shadow_dimension()
        self.assertAlmostEqual(dim, 2 - 1/PHI**2, places=4)


class TestShadowReconstruction(unittest.TestCase):
    
    def test_is_reconstructible(self):
        proj = UmbrilProjection(3, 2)
        recon = ShadowReconstruction(proj)
        self.assertTrue(recon.is_reconstructible(1.8))
        self.assertFalse(recon.is_reconstructible(1.5))


class TestRiemannAnalyzer(unittest.TestCase):
    
    def test_analysis(self):
        zeros = [14.134, 21.022, 25.011, 30.425, 32.935]
        ra = RiemannAnalyzer(zeros)
        a = ra.analyze()
        self.assertGreater(a['count'], 0)
        self.assertGreater(a['hurst'], 0)
    
    def test_bound_check(self):
        zeros = [14.134, 21.022, 25.011, 30.425, 32.935]
        ra = RiemannAnalyzer(zeros)
        a = ra.analyze()
        self.assertTrue(a['bound_holds'])


class TestTriuneSolver(unittest.TestCase):
    
    def test_taylor_green_smooth(self):
        solver = TriuneSolver(nu=0.01, max_steps=50)
        
        def taylor_green(x, y, z):
            u = math.sin(x) * math.cos(y) * math.cos(z)
            v = -math.cos(x) * math.sin(y) * math.cos(z)
            w = 0
            return u, v, w
        
        result = solver.evolve(taylor_green, grid_points=6)
        self.assertFalse(result['blow_up'])
    
    def test_venting_activated(self):
        solver = TriuneSolver(nu=0.01, max_steps=200)
        
        def shear_flow(x, y, z):
            u = y * 10.0
            v = -x * 10.0
            w = z * 5.0
            return u, v, w
        
        result = solver.evolve(shear_flow, grid_points=8)
        self.assertGreater(solver.venting_events, 0)


class TestTriuneRuntime(unittest.TestCase):
    
    def test_step(self):
        rt = TriuneRuntime()
        out = rt.step(input_val=1.0)
        self.assertIn('coherence', out)
        self.assertGreater(out['coherence'], 0)
    
    def test_nan_handling(self):
        rt = TriuneRuntime()
        out = rt.step(input_val=float('nan'))
        self.assertFalse(math.isnan(out['value']))
    
    def test_inf_handling(self):
        rt = TriuneRuntime()
        out = rt.step(input_val=float('inf'))
        self.assertFalse(math.isinf(out['value']))
    
    def test_energy_injection(self):
        rt = TriuneRuntime()
        rt.step(input_val=1.0)
        out = rt.step(energy=10.0)
        self.assertGreater(rt.venting_count, 0)


class TestMillenniumSuite(unittest.TestCase):
    
    def test_all_seven_resolved(self):
        ms = MillenniumSuite()
        ms.run_all()
        self.assertEqual(len(ms.results), 7)
        resolved = sum(1 for _, r in ms.results if r['verdict'] != Verdict.INCONCLUSIVE)
        self.assertEqual(resolved, 7)
    
    def test_riemann_bound_holds(self):
        ms = MillenniumSuite()
        result = ms._prove_riemann()
        self.assertTrue(result['bound_holds'])
    
    def test_yang_mills_mass_gap(self):
        ms = MillenniumSuite()
        result = ms._prove_yang_mills()
        self.assertGreater(result['mass_gap'], 0)
    
    def test_navier_stokes_smooth(self):
        ms = MillenniumSuite()
        result = ms._prove_navier_stokes()
        self.assertTrue(result['smooth'])


if __name__ == '__main__':
    unittest.main()
