from setuptools import setup, find_packages
setup(
    name='umbril',
    version='1.0.0',
    description='Triune Fractal Theorem — phi-harmonic floating-point fix',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Umbril Research',
    author_email='Codyross247@gmail.com',
    packages=find_packages(),
    python_requires='>=3.8',
)
