#!/usr/bin/env python3
"""
UMBRIL REPL — Interactive Triune Runtime Console
=================================================
Type values to process them through the full triune loop.
Commands:
  /help      — Show this message
  /phi       — Show φ constant
  /grid N    — Show 3-6-9 grid up to scale N
  /zero N    — Analyze first N Riemann zeros
  /millennium — Run all 7 Millennium problems
  /monitor   — Start spectral monitoring session
  /stop      — Stop monitoring session
  /state     — Show current runtime state
  /reset     — Reset runtime
  /quit      — Exit

Every other input is processed as a value through:
  structure → observe → close → cohere → select → integrate
"""

import sys
import os
import math
import readline

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from umbril.core import PHI, PHI_INV, D, EPS, UmbrilFloat, PhiNumber, GuardedFloat
from umbril.stability import SpectralMonitor
from umbril.analysis import (
    TriuneRuntime, CoherenceLevel,
    RiemannAnalyzer, MillenniumSuite, TriuneSolver,
)

# ═══════════════════════════════════════════════════════════════
# GLOBALS
# ═══════════════════════════════════════════════════════════════

runtime = TriuneRuntime("REPL")
monitor = None
history = []

# Known Riemann zeros for analysis
RIEMANN_ZEROS = [
    14.134725, 21.022040, 25.010858, 30.424876, 32.935062,
    37.586178, 40.918719, 43.327073, 48.005151, 49.773832,
    52.970321, 56.446248, 59.347044, 60.831779, 65.112544,
    67.079811, 69.546402, 72.067158, 75.704691, 77.144840,
    79.337375, 82.910381, 84.735493, 87.425275, 88.809111,
    92.491899, 94.651344, 95.870634, 98.831194, 101.317851,
]

# ═══════════════════════════════════════════════════════════════
# DISPLAY HELPERS
# ═══════════════════════════════════════════════════════════════

COHERENCE_COLORS = {
    CoherenceLevel.OPTIMAL: '\033[92m',   # Green
    CoherenceLevel.STABLE: '\033[94m',    # Blue
    CoherenceLevel.DEGRADING: '\033[93m', # Yellow
    CoherenceLevel.UNSTABLE: '\033[91m',  # Red
    CoherenceLevel.COLLAPSED: '\033[90m', # Grey
}
RESET = '\033[0m'
BOLD = '\033[1m'

def color_coherence(level):
    return f"{COHERENCE_COLORS.get(level, '')}{level.value.upper()}{RESET}"

def print_state(result):
    """Print the runtime state after a step."""
    level = result['level']
    color = COHERENCE_COLORS.get(level, '')
    
    print(f"\n  {BOLD}┌─ Triune Loop Complete{': STRUCTURE → OBSERVE → CLOSE → COHERE → SELECT → INTEGRATE ─┐' if len(history) <= 1 else ''}")
    print(f"  ├─ Value:      {result['value']:>12.6f}")
    print(f"  ├─ Coherence:  {color}{result['coherence']:>12.4f}{RESET}  ({level.value})")
    print(f"  ├─ Entropy:    {result['entropy']:>12.2e}")
    print(f"  ├─ Venting:    {result['venting']:>12} events")
    print(f"  └─ Grid scale: {runtime.value / (3 * max(runtime.macro_buf[-1] if runtime.macro_buf else 1, 0.001) / max(abs(runtime.value), 0.001)) if False else ''}")
    
    gs = 0 if runtime.value == 0 else round(math.log(max(abs(runtime.value), 1e-300), 3))
    closure = 3 * gs
    aligned = abs(runtime.value - closure) < EPS * abs(runtime.value) * 10
    print(f"     Grid:       scale={gs}, closure={closure}, aligned={'✓' if aligned else '✗'}")
    
    phi_dist = abs(abs(runtime.value) - PHI)
    phi2_dist = abs(abs(runtime.value) - PHI**2)
    nearest = 'φ' if phi_dist < phi2_dist else 'φ²'
    print(f"     φ-distance: {phi_dist:.4f} (nearest harmonic: {nearest})")
    print()

def print_header():
    print(f"\n{BOLD}{'═'*60}{RESET}")
    print(f"{BOLD}  UMBRIL REPL — Interactive Triune Runtime{RESET}")
    print(f"{BOLD}{'═'*60}{RESET}")
    print(f"  φ = {PHI:.6f}    φ⁻¹ = {PHI_INV:.6f}    d = {D:.4f}")
    print(f"  Type a number to process it.  /help for commands.")
    print(f"{'═'*60}\n")

def print_help():
    print(f"""
  {BOLD}COMMANDS:{RESET}
  /help          Show this message
  /phi           Show φ and its powers
  /grid N        Show 3-6-9 grid up to scale N (default 9)
  /zero N        Analyze first N Riemann zeros (max 30)
  /millennium    Run all 7 Millennium Prize problems
  /monitor       Start spectral monitoring session
  /stop          Stop monitoring and show report
  /state         Show full current runtime state
  /reset         Reset the runtime to initial state
  /clear         Clear screen
  /quit          Exit
  
  {BOLD}ANY OTHER INPUT{RESET} is processed as a numeric value through
  the complete triune loop and the resulting state is displayed.
  
  {BOLD}Try these:{RESET}
    0.1              — watch the classic float problem
    {PHI}            — φ itself
    -{PHI}           — negative φ  
    100              — large value convergence
    0                — zero crossing
    1e100            — extreme value (φ-normalized)
""")

def print_phi_info():
    print(f"\n  {BOLD}φ (Golden Ratio) = {PHI:.15f}{RESET}")
    print(f"  φ⁻¹  = {PHI_INV:.15f}")
    for i in range(2, 11):
        val = PHI ** i
        # Get exact Fibonacci representation
        fibs = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
        if i < len(fibs) - 1:
            exact = f"{fibs[i-1]} + {fibs[i]}φ"
            print(f"  φ^{i:2d}  = {val:>12.6f}  = {exact}")
        else:
            print(f"  φ^{i:2d}  = {val:>12.6f}")
    print()

def print_grid(scale=9):
    print(f"\n  {BOLD}3-6-9 Grid{RESET}")
    print(f"  {'Scale':<8} {'Container':<12} {'Closure':<10} {'Triad'}")
    print(f"  {'─'*40}")
    for s in range(1, scale + 1):
        container = 3 * (s - 1) if s > 1 else 1
        closure = 3 * s
        print(f"  {s:<8} {container:<12} {closure:<10} ({s}, {-s}, 2)")
    
    print(f"\n  First three roles: 3 (local closure) → 6 (coupling) → 9 (global)")
    print(f"  Then repeats fractally: 12 → 15 → 18 → 21 → ...")
    print()

def print_state_full():
    """Print complete runtime state."""
    out = runtime.step()
    level = out['level']
    
    print(f"\n  {BOLD}═══ FULL RUNTIME STATE ═══{RESET}")
    print(f"  Value:        {runtime.value:.10f}")
    print(f"  Coherence:    {runtime.coherence:.6f}  ({color_coherence(level)})")
    print(f"  Entropy:      {runtime.entropy:.6e}")
    print(f"  Shadow:       {runtime.shadow:.6e}")
    print(f"  Iterations:   {runtime.iteration}")
    print(f"  Venting:      {runtime.venting_count} events, {runtime.energy_vented:.4f} energy")
    
    gs = 0 if runtime.value == 0 else round(math.log(max(abs(runtime.value), 1e-300), 3))
    print(f"  Grid scale:   {gs} (closure at {3*gs})")
    print(f"  φ-distance:   {abs(abs(runtime.value) - PHI):.6f}")
    
    print(f"\n  Buffer sizes: macro={len(runtime.macro_buf)}, "
          f"meso={len(runtime.meso_buf)}, micro={len(runtime.micro_buf)}")
    
    if runtime.macro_buf:
        print(f"  Last macro:   {runtime.macro_buf[-1]:.6e}")
        print(f"  Last meso:    {runtime.meso_buf[-1]:.6e}")
        print(f"  Last micro:   {runtime.micro_buf[-1]:.6e}")
    
    if history:
        print(f"\n  Recent history:")
        for h in history[-5:]:
            print(f"    iter {h['iter']:>3}: val={h['val']:>10.4f}  coh={h['coh']:.4f}")
    print()

# ═══════════════════════════════════════════════════════════════
# COMMAND HANDLERS
# ═══════════════════════════════════════════════════════════════

def handle_value(input_str):
    """Process a numeric value through the triune loop."""
    try:
        val = float(input_str)
    except ValueError:
        # Try as expression
        try:
            val = eval(input_str, {"__builtins__": {}}, 
                      {"phi": PHI, "PHI": PHI, "pi": math.pi, "e": math.e,
                       "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos,
                       "log": math.log, "exp": math.exp})
        except:
            print(f"  ⚠️  Could not parse: {input_str}")
            return
    
    result = runtime.step(input_val=val)
    iter_num = runtime.iteration
    
    history.append({
        'iter': iter_num,
        'val': result['value'],
        'coh': result['coherence'],
        'input': val,
    })
    
    if monitor:
        monitor.track('input', result['value'], val)
    
    print_state(result)

def handle_zero(n):
    """Analyze Riemann zeros."""
    try:
        n = int(n) if n else 10
    except:
        n = 10
    n = min(n, len(RIEMANN_ZEROS))
    
    zeros = RIEMANN_ZEROS[:n]
    ra = RiemannAnalyzer(zeros)
    ra.report()

def handle_monitor():
    global monitor
    monitor = SpectralMonitor("REPL_session")
    monitor.track_value(runtime.value if runtime.value != 0 else PHI, "current_state")
    print(f"\n  🔍 Spectral monitoring started. Every input will be tracked.")
    print(f"  Type /stop to end monitoring and see the report.")

def handle_stop():
    global monitor
    if monitor:
        monitor.report()
        monitor = None
    else:
        print(f"  No active monitoring session.")

def handle_millennium():
    ms = MillenniumSuite()
    ms.run_all()

def handle_reset():
    global runtime, history, monitor
    runtime = TriuneRuntime("REPL")
    history = []
    monitor = None
    print(f"\n  🔄 Runtime reset. φ = {PHI:.6f}")

# ═══════════════════════════════════════════════════════════════
# MAIN REPL LOOP
# ═══════════════════════════════════════════════════════════════

def main():
    print_header()
    
    while True:
        try:
            user_input = input(f"  umbril> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n")
            break
        
        if not user_input:
            continue
        
        # Commands
        if user_input.startswith('/'):
            cmd = user_input[1:].lower().split()
            command = cmd[0] if cmd else ''
            arg = cmd[1] if len(cmd) > 1 else None
            
            if command == 'quit' or command == 'q' or command == 'exit':
                if monitor:
                    handle_stop()
                print(f"\n  Φ = 1\n")
                break
            elif command == 'help' or command == 'h':
                print_help()
            elif command == 'phi':
                print_phi_info()
            elif command == 'grid':
                try:
                    n = int(arg) if arg else 9
                except:
                    n = 9
                print_grid(n)
            elif command == 'zero':
                handle_zero(arg)
            elif command == 'millennium':
                handle_millennium()
            elif command == 'monitor':
                handle_monitor()
            elif command == 'stop':
                handle_stop()
            elif command == 'state':
                print_state_full()
            elif command == 'reset':
                handle_reset()
            elif command == 'clear':
                print('\033[2J\033[H')
                print_header()
            else:
                print(f"  Unknown command: /{command}. Type /help for commands.")
        else:
            handle_value(user_input)

if __name__ == '__main__':
    main()
