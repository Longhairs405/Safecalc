#!/bin/bash
# One-line installer for Umbril Calculator
# curl -sSL https://your-host/install.sh | bash
# Or locally: bash install.sh

echo "Installing Umbril — Triune Fractal Calculator..."
pip install umbril 2>/dev/null || python -m pip install umbril --user --break-system-packages 2>/dev/null
echo ""
echo "Installation complete!"
echo "Run:  umbril-calc"
echo "  or:  python -m umbril.calc"
