# Umbril - Triune Fractal Theorem Calculator

Fixes 0.1+0.2 bug. Contact: Codyross247@gmail.com
